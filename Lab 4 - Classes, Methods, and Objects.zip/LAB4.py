#Lab #4
#Due Date: 09/20/2019, 11:59PM EST
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Tj and help from LA Ian        
#
########################################


class BadSodaMachine:
    '''
        >>> m = BadSodaMachine('Coke', 10)
        >>> m.purchase()
        'Product out of stock'
        >>> m.purchase(2)
        'Product out of stock'
        >>> m.restock(3)
        'Current soda stock: 3'
        >>> m.purchase()
        'Please deposit $10'
        >>> m.deposit(7)
        'Balance: $7'
        >>> m.purchase()
        'Please deposit $3'
        >>> m.purchase(2)
        'Please deposit $13'
        >>> m.deposit(5)
        'Balance: $12'
        >>> m.purchase()
        'Coke dispensed, take your $2'
        >>> m.deposit(20)
        'Balance: $20'
        >>> m.purchase(2)
        'Coke dispensed'
        >>> m.deposit(15)
        'Sorry, out of stock. Take your $15 back'
    '''
    def __init__(self, product, price):
        if (type(price) != int) or (type(product) != str):
            return("Invalid Input for purchase")
        self.amount = 0
        self.balance = 0
        self.product = product
        self.price = price


    # --- YOU CODE STARTS HERE. Notes from Module 1 could be useful here!
    def purchase(self, amount = 1):
        if self.amount <= 0: 
            return "Product out of stock"
        
        if self.balance < (self.price * amount): 
            requiredcost = abs(self.balance - (self.price * amount)) 
            return 'Please deposit $' + str(requiredcost)

        if amount > self.amount: #got help from LA Ian
            return "Not enough stock for your amount"
        
        elif self.balance > (self.price * amount): 
            self.amount = self.amount - amount
            self.balance -= (self.price * amount)
            output = self.product + " dispensed, take your $" + str(self.balance)
            self.balance = 0
            return(output)
        
        else: 
            self.amount = self.amount - amount
            self.balance -= (self.price * amount)
            return self.product + " dispensed"
    


    def deposit(self, amount):
        if self.amount == 0: 
            return "Sorry, out of stock. Take your $" + str(amount) + " back"
        self.balance += amount
        return "Balance: $" + str(self.balance)
   



    def restock(self, amount):
        self.amount += amount
        return 'Current soda stock: ' + str(self.amount)
    

    