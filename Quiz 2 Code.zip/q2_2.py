'''
CMPSC132 - Quiz 2 Coding Exam
November 19th, 2019
'''

## QUESTION 1

def power(x, n):
    '''
        >>> power(3,4)
        81
        >>> power(4,2)
        16
    '''
    # --YOUR CODE STARTS HERE
    if n == 0:
    	return 1
    else:
    	return x * power(x, n-1)







## QUESTION 2

class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def peek(self):
         return self.items[len(self.items)-1]

     def __len__(self):
         return len(self.items)


class Queue:
    '''
        >>> x=Queue()
        >>> x.isEmpty()
        True
        >>> x.dequeue()
        >>> x.enqueue(1)
        >>> x.enqueue(2)
        >>> x.enqueue(3)
        >>> x.dequeue()
        1
        >>> x.dequeue()
        2
        >>> x.enqueue(5)
        >>> x.enqueue(7)
        >>> x.enqueue(-3)
        >>> x.dequeue()
        3
        >>> x
        [5, 7, -3]
    '''
    def __init__(self):
        self.stack_1=Stack()
        self.stack_2=Stack()

    def __str__(self):
        out=self.stack_1.items+self.stack_2.items
        return f'{out}'

    __repr__=__str__

    def isEmpty(self):
        if self.stack_1.isEmpty() and self.stack_2.isEmpty():
            return True
        return False 

    def enqueue(self, value):
        self.stack_1.push(value)

    def dequeue(self):
        if self.isEmpty():
            return None
        # --YOUR CODE STARTS HERE
    	else:
    		self.stack_1.pop() 
    		self.stack_2.push() 
  #What I'm trying to do here is that it pops or takes out the top value in the queue 
   
