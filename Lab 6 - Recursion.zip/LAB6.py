#Lab #6
#Due Date: 10/04/2019, 11:59PM 
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: TA Peter, Stack Overflow, Tj      
#
########################################


## ALL FUNCTIONS MUST BE RECURSIVE IN ORDER TO GET CREDIT FOR THEM


def mulBy(num): #used the Recursion Module PDF from canvas to help me get this code
    '''
        >>> mulBy(5)
        15
        >>> mulBy(8)
        384
        >>> mulBy(0)
        0
        >>> mulBy(1)
        1
    '''
    if not isinstance(num, int):
    	return 'Error'
    if (num < 0):
    	return 'Error; number has to be positive'
    if (num == 0):
    	return num
    elif (num == 1):
    	return num
    elif (num == 2):
    	return num
    else:
        return num * mulBy(num-2)





def flat(aList): #TA Peter helped me with this 
    '''
        >>> x = [3, [[5, 2]], 6, [4]]
        >>> flat(x)
        [3, 5, 2, 6, 4]
        >>> x
        [3, [[5, 2]], 6, [4]]
        >>> flat([1, 2, 3])
        [1, 2, 3]
        >>> flat([1, [], 3])
        [1, 3]
    '''
    if aList == []:
        return aList
    if isinstance(aList[0], list):
        return flat(aList[0]) + flat(aList[1:])
    return aList[:1] + flat(aList[1:])





def isPrime(num, i = 2):
    '''
        >>> isPrime(5)
        True
        >>> isPrime(1)
        False
        >>> isPrime(0)
        False
        >>> isPrime(85)
        False
        >>> isPrime(1019)
        True
        >>> isPrime(2654)
        False
    '''
    if (num < 0): #to show negative numbers can work
    	return "Error;No prime numbers have negative value"
    if (num == 0):
    	return False
    if (num == 1):
    	return False
    if (num % i == 0): 
        return False
    if (num < (i*i)): 
        return True 
    if (num <= 2): 
        return True if(num == 2) else False #used Stack Overflow to help me understand this
    return isPrime(num, i+1)





def countPrimes(num):
    '''
        >>> countPrimes(0)
        0
        >>> countPrimes(6)
        3
        >>> countPrimes(2)
        1
        >>> countPrimes(60)
        17
        >>> countPrimes(100)
        25
        >>> countPrimes(500)
        95
    '''
    if (num < 0): #to show negative numbers can't work for this
    	return "Error:No prime numbers have negative value"
    if num == 0:
    	return 0
    if num == 1:
    	return 1 
    if isPrime(num) == False: #look up how to count recursion to understand how it works
    	return countPrimes(num-1)
    else:
    	return 1 + countPrimes(num-1)





