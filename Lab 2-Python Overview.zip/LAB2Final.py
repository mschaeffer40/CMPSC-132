#Lab #2
#Due Date: 09/06/2019, 11:59PM 
########################################
#                                      
# Name:
# Collaboration Statement: Tj Schaeffer and Python Journal Dev and went to office hours for help          
#
########################################

def removePunctuation(txt):
    """
        >>> removePunctuation("I like chocolate cake!!(!! It's the best flavor..;.$ for real")
        'I like chocolate cake      It s the best flavor      for real'
        >>> removePunctuation("Dots...................... many dots..X")
        'Dots                       many dots  X'
        >>> removePunctuation(55)
        'None'
        >>> removePunctuation([3.5,6])
        'None'
    """
    # --- YOU CODE STARTS HERE
    if not isinstance(txt, str):
        return 'None'

    cList = list(txt)
    counter = 0
    while counter < len(txt):
        letter = cList[counter].isalpha()
        if letter == False:
            cList[counter] = " "
            counter += 1
        else:
            counter += 1
        txt = "".join(cList)
    return (txt)




def studentGrades(gradeList):
    """
        >>> grades = [
        ...     ['Student', 'Quiz 1', 'Quiz 2', 'Quiz 3'],
        ...     ['John', 100, 90, 80],
        ...     ['McVay', 88, 99, 111],
        ...     ['Rita', 45, 56, 67],
        ...     ['Ketan', 59, 61, 67],
        ...     ['Saranya', 73, 79, 83],
        ...     ['Min', 89, 97, 101]]
        >>> studentGrades(grades)
        [90, 99, 56, 62, 78, 95]
        >>> grades = [
        ...     ['Student', 'Quiz 1', 'Quiz 2'],
        ...     ['John', 100, 90],
        ...     ['McVay', 88, 99],
        ...     ['Min', 89, 97]]
        >>> studentGrades(grades)
        [95, 93, 93]
        >>> studentGrades(55)
        'None'
        >>> studentGrades('32')
        'None'
    """
    # --- YOU CODE STARTS HERE
    try:
        if type(gradeList) == list:
            meanList = []
            row = 1
            while row < len(gradeList):
                rowTotal = sum(gradeList[row][1:])
                rowMean = rowTotal / (len(gradeList[1]) - 1)
                rowMean = int(rowMean)
                meanList.append(rowMean)
                row += 1
        else:
            meanList = 'None'
        return(meanList)
   
    except:
        return 'None'