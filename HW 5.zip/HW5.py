#HW 5
#Due Date: 12/13/2019, 11:59PM 
########################################
#
# Name:
# Collaboration Statement: https://stackoverflow.com/questions/15913489/python-find-all-neighbours-of-a-given-node-in-a-list-of-lists
# Tj helped me understand my problems for my enqueue and dequeue so I can fix it
#https://pythoninwonderland.wordpress.com/2017/03/18/how-to-implement-breadth-first-search-in-python/
########################################

# ---Copy your Queue code from lab 8 and your Stack code from HW3 here (you can remove their comments)  
class Node:
    def __init__(self, value):
        self.value = value  
        self.next = None 
    
    def __str__(self):
        return "Node({})".format(self.value) 

    __repr__ = __str__
                          


class Stack:
    def __init__(self):
        self.top = None
        self.count=0
    
    def __str__(self):
        temp=self.top
        out=[]
        while temp:
            out.append(str(temp.value))
            temp=temp.next
        out='\n'.join(out)
        return ('Top:{}\nStack:\n{}'.format(self.top,out))

    __repr__=__str__

    def isEmpty(self):
        if not self.top:
        	return True
        else:
        	return False

    def __len__(self): 
        return self.count

    def peek(self):
        if self.isEmpty() is not True:
        	return self.top.value
        else:
        	return 'Got nothing'

    def pop(self):
    	if self.isEmpty() is not True:
    		currentNode = self.top.value
    		self.top = self.top.next
    		return currentNode
    	else:    	
    		return

    def push(self,value):
        node = Node(value)
        node.next = self.top
        self.top = node
        self.count+=1
 
class Queue:
    def __init__(self): 
        self.head=None
        self.tail=None
        self.count=0

    def __str__(self):
        temp=self.head
        out=[]
        while temp:
            out.append(str(temp.value))
            temp=temp.next
        out=' '.join(out)
        return f'Head:{self.head}\nTail:{self.tail}\nQueue:{out}'

    __repr__=__str__
           
    
    def enqueue(self, x): 
    	node = Node(x)
    	if self.isEmpty() is not True:
    		currentNode = self.tail
    		currentNode.next = node
    		self.tail = node
    	else:
    		self.head = node
    		self.tail = node
    	self.count = self.count + 1                 
  
    def dequeue(self):
        if self.isEmpty() is True:
            return 'Queue is empty' 
   
        firstNode = self.head
        self.head = firstNode.next
        self.count = self.count - 1
        if self.count == 0:
        	self.tail = None
        return firstNode.value

    def reverse(self):
    	current = self.head
    	previous = None
    	oldHead = self.head
    	while current is not None:
    		follow = current.next
    		current.next = previous
    		previous = current
    		current = follow
    	self.head = previous
    	self.tail = oldHead
   
 
    def __len__(self): 
   
        temp=self.head 
        count=0
        while temp is not None: 
            count=count+1
            temp=temp.next
        return count 
       
      
    def isEmpty(self): 
        if self.head is None: 
            return True
        return False





#----- HW5 Graph code     
class Graph:
    def __init__(self, graph_repr):
        self.vertList = graph_repr


    def bfs(self, start):
        '''
            >>> g1 = {'A': ['B','D','G'],
            ... 'B': ['A','E','F'],
            ... 'C': ['F'],
            ... 'D': ['A','F'],
            ... 'E': ['B','G'],
            ... 'F': ['B','C','D'],
            ... 'G': ['A','E']}
            >>> g=Graph(g1)
            >>> g.bfs('A')
            ['A', 'B', 'D', 'G', 'E', 'F', 'C']
        '''
        # YOUR CODE STARTS HERE
        #pythoniwonderland helped me understand BFS
        q = Queue()
        q.enqueue(str(start))
        letterList = []
        letterList.append(str(start))
        while q.isEmpty() is not True:
        	new_node = q.dequeue()
        	#used Stack Overflow to help me with this 
        	lst = [neighbor[0] for neighbor in self.vertList[str(new_node)]]
        	lst.sort()
        	for neighbor in lst:
        		if neighbor not in letterList:
        			q.enqueue(str(neighbor))
        			letterList.append(str(neighbor))
        return letterList

    def dfs(self, start):
        '''
            >>> g1 = {'A': ['B','D','G'],
            ... 'B': ['A','E','F'],
            ... 'C': ['F'],
            ... 'D': ['A','F'],
            ... 'E': ['B','G'],
            ... 'F': ['B','C','D'],
            ... 'G': ['A','E']}
            >>> g=Graph(g1)
            >>> g.dfs('A')
            ['A', 'B', 'E', 'G', 'F', 'C', 'D']
        '''
        # OUR CODE STARTS HERE
        s = Stack()
        s.push(start)
        letterList = []
        while s.isEmpty() is not True:
        	new_node = s.pop()
        	if isinstance(new_node, tuple):
        		new_node = new_node[0]
        	if new_node not in letterList:
        		letterList.append(str(new_node))
        		#used Stack Overflow to help me with this 
        		lst = [neighbor[0] if isinstance(neighbor, tuple) else neighbor for neighbor in self.vertList[str(new_node)]]
        		lst.sort()
        		lst = lst[::-1]
        	for neighbor in lst:
        		if neighbor not in letterList:
        			s.push(str(neighbor))
        return letterList

