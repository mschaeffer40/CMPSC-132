# 10/08 Quiz 1 - Coding Part
# Name: Matthew Schaeffer
#

import math   # you can use math.pi


##QUESTION 1
'''
    Doctest:
    >>> a=Figure(6) 
    Traceback (most recent call last):
    File "<stdin>", line 1, in <module>
    TypeError: Can't instantiate abstract class Figure with abstract methods area, perimeter
    >>> a=Circle(9)
    >>> a.perimeter        # 2*pi*r
    56.548667764616276
    >>> a.area          # pi*r**2
    254.46900494077323
    >>> a=Rectangle(2,5) 
    >>> a.perimeter     #2*(w + h)
    14
    >>> a.area    # w * h
    10
'''
class Figure:
 	def __init__(self, name):
 		self.name = name
class Rectangle(Figure):
	def __init__(self, name):
		self.width = w
		self.height = h
	def perimeter(self, height, width):
		return Rectangle(2*(w+h))
	def area(self, height, width):
		return Rectangle(w*h)
class Circle(Figure):
	def __init__(self, name):
		self.radius = r
	def perimeter(self, radius):
		return Circle(2*3.14*r)
	def area(self, radius):
		return Rectangle(3.14*(r**2))




##QUESTION 2
'''
    Doctest:
    >>> p1=Point2D(-7,-9)
    >>> p2=Point2D(1,5.6)
    >>> line1=Line(p1,p2)
    >>> line1.distance
    16.648
    >>> line1.midpoint
    (-3.0, -1.7)
    >>> p1=Point3D(1,2,3)
    >>> p2=Point3D(4,5,5)
    >>> line2=Line(p1,p2)
    >>> line2.distance
    4.69
    >>> line2.midpoint
    (2.5, 3.5, 4.0)
'''
import math
class Point2D:
	def __init__(self, p1, p2):
		self.p1 = point1
		self.p2 = point2
class Point3D:
	def __init__(self, p1, p2):
		self.p1 = point1
		self.p2 = point2

class Line: 
    def __init__(self, point1, point2):
    	self.point1 = p1
    	self.point2 = p2
    def distance(self,other):
    	return Line(math.sqrt(((self.p2-self.p1)**2) + ((other.p2-other.p1)**2)))
    def midpoint(self,other):
    	return Line(((self.p1+self.p2)/2),((other.p2+other.p1)/2))
    
    

