#Lab #7
#Due Date: 10/11/2019, 11:59PM 
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: https://www.programiz.com/python-programming/break-continue and Adam Brightbill             
#
########################################

class Node:
    def __init__(self, value):
        self.value = value  
        self.next = None 
    
    def __str__(self):
        return "Node({})".format(self.value) 

    __repr__ = __str__
                        
                          
class OrderedLinkedList:
    '''
        >>> x=OrderedLinkedList()
        >>> x.pop()
        >>> x.add(8.76)
        >>> x.add(1)
        >>> x.add(1)
        >>> x.add(1)
        >>> x.add(5)
        >>> x.add(3)
        >>> x.remDuplicates()
        >>> x.pop()
        8.76
        >>> x
        Head:Node(1)
        Tail:Node(5)
        List:1 3 5
    '''

    def __init__(self):
        self.head=None
        self.tail=None
        self.count=0

       

    def __str__(self):
        temp=self.head
        out=[]
        while temp:
            out.append(str(temp.value))
            temp=temp.next
        out=' '.join(out) 
        return f'Head:{self.head}\nTail:{self.tail}\nList:{out}'

    __repr__=__str__

    def __len__(self):
    	count = 0
    	value = self.head
    	while value is not None:
    		count+=1
    		value = value.next
    	return(count)

    def pop(self): 
    	if self.head is None:
    	    return None
    	if self.head == self.tail:
    	    value = self.head.value
    	    self.head = None
    	    self.tail = None
    	    return(value)
    	previous = self.head
    	while previous.next != self.tail:
    	    previous = previous.next
    	value = self.tail.value
    	previous.next = None
    	self.tail = previous
    	return(value)

    def add(self, value):
    	newNode=Node(value)
    	if self.head == None:
    		self.head=newNode
    		self.tail=newNode
    		self.count+=1
    		return
    	if self.head.value > newNode.value:
    		newNode.next = self.head
    		self.head = newNode
    		self.count+=1
    		return


    	current = self.head
    	prev = None
    	while current is not None:
    		if current.value > value:
    			newNode.next = current
    			prev.next = newNode
    			self.count += 1
    			return
    		else:
    			prev = current
    			current = current.next
    	self.tail.next = newNode
    	newNode.next = None
    	self.tail = newNode
    	self.count+=1
    	return

    def isEmpty(self):
    	if self.head is None:
    		return True
    	else:
    		return False
    
    def remDuplicates(self):
        # --- Your code starts heref
        current1 = current2 = self.head
        while current1 is not None:
        	while current2.next is not None:
	        	if current2.next.value == current1.value:
	        		current2.next = current2.next.next
	        	else:
	        		current2 = current2.next
	        current1 = current2 = current1.next
    		

     




