#HW #1
#Due Date: 09/20/2019, 11:59PM 
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Tj and help from TA Peter            
#
########################################



def isPower(x, y):
    """
        >>> isPower(4, 64)
        3
        >>> isPower(5, 81)
        -1
        >>> isPower(7, 16807)
        5
    """
    power = 1
    value = 0
    while y > power:
    	power *= x
    	value += 1
    if power != y:
    	return -1
    else:
    	return value
    	

def translate(translationDict, txt):
    """
        >>> myDict = {'up': 'down', 'down': 'up', 'left': 'right', 'right': 'left', '1': 'one'} 
        >>> text = 'Up down left Right forward 1 time' 
        >>> translate(myDict, text) 
        'down up right left forward one time'
    """
    if not isinstance(txt, str) or not(translationDict,dict):
    	return 'None'


    output_list = []
    txt = txt.lower()
    lst = txt.split()
    for word in lst:
    	if word in translationDict.keys():
    		new_word = translationDict[word]
    		output_list.append(new_word)
    	else: 
    		output_list.append(word)
    final_output = ' '.join(output_list)
    return final_output




def onlyTwo(x, y, z):
    """
        >>> onlyTwo(1, 2, 3)
        13
        >>> onlyTwo(3, 3, 2)
        18
        >>> onlyTwo(5, 5, 5)
        50
    """
    first = max(x,y)
    second = max(y,z)
    if first == second:
        second = max(x,z)
    return first**2 + second**2



def largeFactor(num):
    """
        >>> largeFactor(15) 
        5
        >>> largeFactor(24)
        12
        >>> largeFactor(7)
        1
    """
    factorials = []
    for value in range(1,num):
    	if num % value == 0:
    		factorials.append(value)
    		biggestFactor = factorials[-1]
    return biggestFactor
    	


def hailstone(num):
    """
        >>> hailstone(5)
        [5, 16, 8, 4, 2, 1]
        >>> hailstone(6)
        [6, 3, 10, 5, 16, 8, 4, 2, 1]
    """
    newList = []
    newList.append(num)
    while num > 1:
    	if num % 2 != 0:
    		num = (num * 3) + 1
    	else:
    		num /= 2
    	newList.append(int(num))
    return newList
