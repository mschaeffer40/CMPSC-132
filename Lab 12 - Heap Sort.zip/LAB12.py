#LAB 12
#Due Date: 11/22/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Wei Lin helped me understand my mistakes that I made in LAB 9          
#
########################################

class MinHeap:
    ### Copy and paste your code from LAB 9 here
    def __init__(self):
        self.heap=[]
        

    def __str__(self):
    	return f'{self.heap}'

    __repr__=__str__


    def parent(self,index):
        if index > len(self.heap) or index <= 1:
        	return None
        return self.heap[index//2-1]
        


    def leftChild(self,index):
        if index < 1 or 2*index > len(self.heap):
        	return None
        return self.heap[2*index-1]



    def rightChild(self,index):
        if index < 1 or 2*index + 1 > len(self.heap):
        	return None
        return self.heap[2*index]



    def __len__(self):
        return(len(self.heap))

       

    def insert(self,x):
        self.heap.append(x)
        current = len(self.heap)
        while self.parent(current) is not None and self.parent(current) > x:
        	self.heap[current-1], self.heap[current//2-1] = self.heap[current//2-1], self.heap[current-1]
        	current = current//2
        	
       
    @property
    def deleteMin(self):
        if len(self)==0:
            return None        
        elif len(self)==1:
            out=self.heap[0]
            self.heap=[]
            return out
        deleted = self.heap[0]
        current = 1
        self.heap[0]=self.heap[-1]
        self.heap.pop()
        moved_number = 1
        while self.leftChild(current) is not None:
        	if self.heap[0] > self.leftChild(current)and self.rightChild(current) > self.leftChild(current):
        		element = self.heap.index(self.leftChild(current))
        		self.heap[0], self.heap[element] = self.heap[element], self,heap[0]
        		current = current * 2
        	elif self.rightChild(current) is not None and self.heap[0] > self.rightChild(current) and self.leftChild(current) > self.rightChild(current):
        		element = self.heap.index(self.rightChild(current))
        		self.heap[0], self.heap[element] = self.heap[element], self,heap[0]
        		current = current * 3
        		moved_number = 2
        	else:
        		if self.rightChild(current) is not None and self.leftChild(current) > self.rightChild(current):
        			element = self.heap.index(self.rightChild(current))
        			self.heap[moved_number], self.heap[element] = self.heap[element], self,heap[moved_number]
        			moved_number = 2*moved_number+2
        			current = current*2+1
        		if self.rightChild(current) is not None and self.leftChild(current) < self.rightChild(current):
        			element = self.heap.index(self.leftChild(current))
        			self.heap[moved_number], self.heap[element] = self.heap[element], self,heap[moved_number]
        			moved_number = moved_number*2+2
        			current = current*2
        		if self.rightChild(current) is not None and self.leftChild(current) is not None:
        			element = self.heap.index(self.leftChild(current))
        			self.heap[moved_number], self.heap[element] = self.heap[element], self,heap[moved_number]
        			moved_number = moved_number*2+2
        			current = current*2

        return deleted


def heapSort(numList):
    '''
       >>> heapSort([9,7,4,1,2,4,8,7,0,-1])
       [-1, 0, 1, 2, 4, 4, 7, 7, 8, 9]
    '''
    sort_heap = MinHeap()
    # -- YOUR CODE STARTS HERE
    while numList:
        sort_heap.insert(numList.pop(-1))
    return sort_heap