#Lab #3
#Due Date: 09/13/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Abid Ahmed and StackOverflow Python and Parker Lewis         
#
########################################

def isPalindrome(text):
    """
        >>> isPalindrome("alula")
        True
        >>> isPalindrome("love")
        False
        >>> isPalindrome("Madam")
        True
        >>> isPalindrome(12.5)
        False
        >>> isPalindrome(12.21)
        False
        >>> isPalindrome("Cigar? Toss it in a can.! It is so tragic.")
        True
        >>> isPalindrome("travel.. a town in Alaska")
        False
    """
    # --- YOU CODE STARTS HERE
    if not isinstance(text, str):
        return False
    text = text.lower()
    for n in text:
    	if n.isalpha() == False: 
    		text = text.replace(n,"")

    for n in range(0, len(text)):
    	if (text[0+n]) != (text[len(text)-1]):
    		return False
    	else:
    		return True



	

