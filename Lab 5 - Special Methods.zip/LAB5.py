#Lab #5
#Due Date: 09/27/2019, 11:59PM EST
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Stack Overflow and TJ helped me understand the ternary operator and worked on it with TJ as well             
#
########################################


class Complex:
    '''
        >>> a=Complex(5,-6)
        >>> b=Complex(2,14)
        >>> a+b
        (7, 8i)
        >>> a-b
        (3, -20i)
        >>> a*b
        (94, 58i)
        >>> b*5
        (10, 70i)
        >>> 5*b
        (10, 70i)
        >>> print(a)
        5-6i
        >>> print(b)
        2+14i
        >>> b
        (2, 14i)
        >>> isinstance(a+b, Complex)
        True
        >>> a.conjugate
        (5, 6i)
        >>> b==Complex(2,14)
        True
        >>> a==b
        False
    '''
    from math import pow
    def __init__(self, real, imag):
        self.real = real
        self.imag = imag
    def __add__(self, other):
        return Complex(self.real+other.real, self.imag+other.imag)#Addition function
    def __sub__(self, other):
        return Complex(self.real-other.real, self.imag-other.imag)#Subtraction function
    def __mul__(self, other):
        return Complex(self.real*other.real-self.imag*other.imag, self.real*other.imag+self.imag*other.real)#Multiplication function
    def __str__(self):
        return str(int(self.real))+('+' if self.imag>=0 else '-')+(str(int(abs(self.imag))))+'i' #learn ternary operator from Pylo
    def __repr__(self): 
    	return '({}' ',' ' ' '{}i)'.format(self.real, self.imag)#Represents the string in the format that is given
    @property
    def conjugate(self):
    	return Complex(self.real, (-1*self.imag))#Conjugate function that takes the opposite numerical operator for complex numbers
    def __rmul__(self,other):
    	return self.__mul__(other)
    def __eq__(self, other):
    	return str(self) == str(other) #Help from Stack Overflow
