#Lab #14
#Due Date: 12/13/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Tj explained to me my mistakes I made in my code in genAccum          
# https://stackoverflow.com/questions/35640780/python-fastest-way-to-find-indexes-of-item-in-list
########################################


def genInf(aList):
    '''
        >>> g = genInf([5,'a',2])
        >>> next(g)
        5
        >>> next(g)
        'a'
        >>> next(g)
        2
        >>> next(g)
        5
        >>> next(g)
        'a'
        >>> next(g)
        2
    '''
    # YOUR CODE STARTS HERE
    #Stack Overflow helped me understand certain parts of genINF()
    #turns function in generator and returns an value to caller called the next value.
    value = 0
    numberCount = value
    #returns the value and maintains local state of function so it can continue where it left off
    while True:
        if numberCount == len(aList):
            numberCount = 0
        yield aList[numberCount]
        numberCount = numberCount + 1



def genFilter(seq, fn):
    """ 
        >>> isEven = lambda x: x % 2 == 0 
        >>> list(genFilter(range(5), isEven)) 
        [0, 2, 4]
        >>> oddNum = (2*i-1 for i in range (10)) 
        >>> list(genFilter(oddNum, isEven)) 
        []
        >>> g = genFilter(range(1,11), isEven) 
        >>> next(g) 
        2
        >>> next(g) 
        4
        >>> next(g) 
        6
        >>> next(g) 
        8
        >>> next(g) 
        10
        >>> next(g) 
        Traceback (most recent call last):
        ...
        StopIteration
    """
    # YOUR CODE STARTS HERE
    for number in seq:
        if fn(number):
            yield number


def genAccum(seq, fn):
    '''
        >>> add = lambda x, y: x + y
        >>> mul = lambda x, y: x * y
        >>> list(genAccum([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], add))
        [1, 3, 6, 10, 15, 21, 28, 36, 45, 55]
        >>> list(genAccum([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], mul))
        [1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800]
    '''
    # YOUR CODE STARTS HERE
    num = None
    solution = []
    for i in seq:
        if num != None:
            num = fn(num, i)
        else:
            num = i
        solution.append(num)
    return solution