Name: Matthew Schaeffer
Collaboration Statement: 


from abc import *
import random

'''This class Account(ABC) sets the inital balance and interest as well as holder for the accounts. 
It also creates a ID that gives the person an indentification so they can access their account by them only.
 '''
class Account(ABC):

    INTEREST = 0

    def __init__(self, account_holder):
        self.holder = account_holder
        self.balance = 0
        self.__id=self.__createID

    @property
    def __createID(self): #creates private ID for person's account out of random integers
        return random.randint(100,9000)

    @property
    def getID(self): #asking for ID
        return self.__id

    def setID(self, new_id): #setting and making your ID your new ID
        self.__id=new_id

    @abstractmethod
    def greeting(self):
        raise NotImplementedError('Subclass implements this method')

    def deposit(self, amount): #deposit money into holders' balance and tells if the check has been paid or not
        if isinstance(amount, (int,float)):
            self.balance = self.balance + amount
            return self.balance
        elif isinstance(amount, Check):
            if amount.pay_to==self.holder and (not amount.cashed) and amount.check_amount>0:
                self.balance+=amount.check_amount
                amount.cashed=True
                return self.balance
            else:
                return 'you are trying to steal money'

        else:
            return 'invalid operation'

    def withdraw(self, amount): #withdraws money from holders' balance and tells if the amount added into the balance is enough or not
        if isinstance(amount, (int,float)):
            if amount > self.balance:
                return 'Not enough funds'
            self.balance = self.balance - amount
            return self.balance
        else:
            return 'invalid operation'

'''This class acknowledges that this is the checking account and the interest and fees it has with withdraw  money to this account '''
class CheckingAccount(Account):

    WITHDRAW_FEE = 1
    INTEREST = 0.01
 
    def __init__(self,name): initializes holders name
        super().__init__(name)
        print(self.greeting())

    def withdraw(self, amount): #withdraws from checking account
        return Account.withdraw(self, amount + CheckingAccount.WITHDRAW_FEE)

    def greeting(self): #greeting
        return f'Welcome to your Checking Account, {self.holder}!'

'''This class acknowledges that this is the savings account and the limits and fees it has with withdraw and depositing money to this account '''
class SavingsAccount(Account):
    INTEREST = 0.03
    DEPOSIT_FEE = 1
    WITHDRAW_FEE = 2
    MIN_BALANCE =250

    def __new__(cls, name, balance):
        if balance<500:
            raise TypeError('Balance not met')
        instance = super(SavingsAccount, cls).__new__(cls)
        return instance

    def __init__(self, name, balance): #initializes name of holder and the balance for saving account
        super().__init__(name)
        self.balance = balance + 100
        print(self.greeting())

    def greeting(self):
        return f'Welcome to your Account, {self.holder}!'

    def deposit(self, amount): #deposit money into savings
        return Account.deposit(self, amount-SavingsAccount.DEPOSIT_FEE)

    def withdraw(self, amount): #withdraw money from savings 
        if self.balance-amount+ SavingsAccount.WITHDRAW_FEE>=SavingsAccount.MIN_BALANCE:
            return Account.withdraw(self, amount + SavingsAccount.WITHDRAW_FEE)
        return 'min balance error'

'''This class shows paying a check of some amount to account '''
class Check:

    def __init__(self, pay_to, amount):
        self.pay_to=pay_to
        self.check_amount=amount
        self.cashed=False
        self.fee=0

    def __str__(self): #string form 
        return 'Pay to the order of: {} ${}'.format(self.pay_to, self.check_amount+self.fee)

    def __repr__(self):
        return f'Cashed: {self.cashed}'

    def __sub__(self, other):
        if isinstance(other, (int,float)):
            self.check_amount-=other
            self.fee=other
            return self

'''This class sets up a Bank where it has created a list for the accounts to go into as well as open
the accounts in the list when the Bank deposits money. They could insert money or pay their interest to all accounts.
Finally, the Bank approves loan and puts money into holders' account '''
class Bank:
    def __init__(self): #initializes a list for the accounts to go into
        self.accounts = []

    def openAccount(self, holder, amount, account_type=Account):
        """Open an account_type for holder and deposit amount."""
        account = account_type(holder)
        account.deposit(amount)
        self.accounts.append(account)
        return account

    def payInterest(self):
        """Pay interest to all accounts."""
        for account in self.accounts:
            account.deposit(account.balance * account.INTEREST)

    def approve_loan(self, amount, balance): #approves loan goes through and puts money into accounts
    	self.balance = self.balance + amount
    	return(self.name, "has", self.balance, "dollars loaned into account")
'''This class accepts that it's a person '''
class Person:
	account_list = {}
	def __init__(self, holder, dob): #initializes name of holder and dob
		self.holder = holder
		self.dob = dob
'''this class acknowledges the fact that the person is a manager who helps delete an account and access detailed info of the holders' account '''
class Manager(Teller):
	def __init__(self, holder):
		self.holder = holder

	def getDetails(self, customer): #accessing detail information of customer
		if customer is in self.account_list[self.__ssn]:
			return f'Balance = ${self.balance}, SSN = {self.__ssn}, DOB = {self.dob}'
		else:
			return 'Customer Can Not Be found.'

	def delete_account(self, customer): #deleting account from list
		if customer not in self.account_list[self.__ssn]:
			return 'Customer Can Not Be found'
		else:
			self.account_list.pop(self.__ssn)
'''this class acknowledges the fact that the person is a customer '''
class Customer(Person):
	account_list = {}
	def __init__(self, holder, ssn, balance): #initializes the ssn, holder of account, the balance, and their dob
		super().__init__(holder)
		self.holder = holder
		self.__ssn = ssn
		self.balance = 0
		self.dob = dob

	def add_account(self): #open new account into account list
		if self.holder in self.account_list:
			return self.__ssn
		else:
			self.account_list[self.__ssn] = [self.holder, self.balance, self.dob]

	def deposit(self, amount): #deposit to whatever account they desire
    	self.balance = self.balance + amount
        return self.balance

	def withdraw(self, amount): #withdraw from whatever account they desire
        if (amount + withdraw_fee) > self.balance:
            return 'Not enough funds'
        self.balance = self.balance - amount
        return self.balance

'''This class acknowledges the fact that the person is an Assistant '''
class Assistant(Person):
	def __init__(self, holder):
		self.holder = holder

	@abstractmethod
	def getDetails(self): #cannot see details
		raise NotImplementedError("Subclass must implement abstract method")

	def approveLoan(self, amount, loan): #checks to approve loan
		if self.loan >250:
			return(Bank.approve_loan(self.amount, self.balance))

'''This class acknowledges the fact that the person is a Teller '''		
class Teller(Employee):
	def __init__(self, holder):
		super().__init__(holder)
		self.holder = holder

	def getDetails(self, customer): #sees only the balance in account
		if customer is in account_list[self.holder]:
			return f'Balance = ${self.balance}'
		else:
			return 'Not found.'











    

		


