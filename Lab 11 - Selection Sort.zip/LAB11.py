#LAB 11
#Due Date: 11/22/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Parker Lewis helped me figure out how to get rid the apostrophes in my output         
# Selection Sort Program Python Stack Overflow
# 

########################################


def selectionSort(numList):
    '''
        Takes a list and returns 2 values
        1st returned value: a dictionary with the state of the list after each complete pass of selection sort
        2nd returned value: the sorted list

        >>> selectionSort([9,3,5,4,1,78,67])
        ({1: [9, 3, 5, 4, 1, 78, 67], 2: [1, 3, 5, 4, 9, 78, 67], 3: [1, 3, 5, 4, 9, 78, 67], 4: [1, 3, 4, 5, 9, 78, 67], 5: [1, 3, 4, 5, 9, 78, 67], 6: [1, 3, 4, 5, 9, 78, 67], 7: [1, 3, 4, 5, 9, 67, 78]}, [1, 3, 4, 5, 9, 67, 78])
    '''
    # YOUR CODE STARTS HERE
    n = len(numList)
    dictionary = {}
    count = 0
    i = 0
    for k in range(n):
    	count = count + 1
    	newList = numList[:]
    	dictionary.update({count: newList})
    	item = k
    	for i in range(item, n): #I used information from the stack overflow website above and the lecture videos to help me understand this
    		if numList[item]>numList[i]:
    			item = i
    	numList[k], numList[item]=numList[item], numList[k]
    return dictionary, numList