#Lab #1
#Due Date: 08/30/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: work with TJ Schaeffer and Adam Smith helped me figure out my errors           
#
########################################
def sumSquares(aList):
    """
        >>> sumSquares(5)
        'error'
        >>> sumSquares('5')
        'error'
        >>> sumSquares(6.15)
        'error'
        >>> sumSquares([1,5,-3,5,9,8,4])
        90
        >>> sumSquares(['3',5,-3,5,9.0,8,4,'Hello'])
        90.0
    """
    if isinstance(aList, list):
    	summation=0
    	
    	for num in aList:
    		if(isinstance(num, float) or isinstance(num, int)):
    			if abs(num) % 3 == 0:
    				summation += num ** 2
    	
    	return summation
    
    else:
    	
    	return "error"












