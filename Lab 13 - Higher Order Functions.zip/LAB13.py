#LAB 13
#Due Date: 12/06/2019, 11:59PM
########################################
#                                      
# Name: Matthew Schaeffer
# Collaboration Statement: Tj helped me understand what I was doing wrong with my code in alternative function         
#
########################################


def digitSum(num):
    '''
        >>> digitSum(15)(555)
        True
        >>> digitSum(22)(2578)
        True
        >>> digitSum(258)(1011010101010)
        False
    ''' 
    def secondFunction(n):
    	final = 0
    	while n > 0:
    		final = final + (n % 10)
    		n = n // 10
    	return num == final
    return secondFunction

def alternate(fn1, fn2):
    '''
        >>> def isEven(x):
        ...    return x % 2 == 0
        >>> ex1 = alternate(isEven, lambda x: x + 4)
        >>> ex1(5)
        [False, 6, False, 8, False]
        >>> ex2 = alternate(lambda x: x * 2, lambda x:x%5 if x<6 else x%2)
        >>> ex2(7)
        [2, 2, 6, 4, 10, 0, 14]
    '''
    def secondAlternate(n):
    	element_list = []
    	for i in range(1, n + 1):
    		if (i%2 != 1):
    			element_list.append(fn2(i))
    		else:
    			element_list.append(fn1(i))
    	return element_list
    return secondAlternate